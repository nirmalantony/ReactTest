import { readFileSync } from "fs";

const txt = readFileSync("test.txt");
console.log("---------", txt.toString())
console.log('hiiii')