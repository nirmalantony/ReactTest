let shallow ={
    name: 'Nirmal',
    age : 35,
    address: 
    {
        house: 'Madathi parambil',
        place: 'cherthala'
    }
}

let shallowcopy = shallow;


console.log('Shallow -----', shallow);
console.log('Shallow copy -----', shallowcopy);