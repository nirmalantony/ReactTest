const express = require('express');



const app = express();

app.get('/', (request, response) => {
  return response.send('Welcome to COCA identity service');
});
app.listen(5000, () =>
    console.log(`Server ready at 5000`)
  )


