const f1 = () =>
{
    console.log('1');
}

const f2 = () =>
{
    
    return  new Promise((resolve,reject)=>
    {
        const val= true;
setTimeout(()=>{
    console.log("2");
    if(val)
    {
        resolve();
    }
    else
    {
        reject();S
    }
    }
    , 100)
});
}

const f3 = ()=>{

    console.log('3');
}

f1();
f2().then(()=>{
f3();
})
