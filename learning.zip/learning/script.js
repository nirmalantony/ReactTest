

// function foo2()
// {
//   return 
//   {
//       bar: "hello"
//   };
// }

// function foo1()
// {
//   return {
//       bar: "hello"
//   };
// }

// console.log("foo1 returns:");
// console.log(foo1());
// console.log("foo2 returns:");
// console.log(foo2());
// console.log(test());
// (function(){
//     var a = b = 3;
//   })();
  
//   console.log("a defined? " + (typeof b ));
//   console.log("a defined? " + (typeof a !== 'undefined'));
//   console.log("b defined? " + (typeof b !== 'undefined'));

const s ="liril"
let s1=s.split('').reverse()