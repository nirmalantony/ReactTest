const f1 = () =>
{
    console.log('1');
}

const f2 = (callback) =>
{
setTimeout(()=>{
    console.log("2");
callback();}
    , 0)
}

const f3 = ()=>{

    console.log('3');
}

f1();
f2(f3);