var express = require('express')
var app = express()

var requestTime =  (req, res, next) =>{
  req.reqTime = Date.now()
  next()
}

app.use(requestTime)

app.use((err,req,res,next)=>
{

})

app.get('/',  (req, res) =>{
  var responseText = 'Hello World!<br>'
  responseText += '<small>Requested at: ' + req.reqTime + '</small>'
  res.send(responseText)
})

app.listen(3000)