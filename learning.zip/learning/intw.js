var array1 = [1, 2, 3, 4, 5]


const fetchDetails = (id)=>
{
  console.log('====fetching details of====='+ id)
  return new Promise((resolve)=>{
    setTimeout(()=>{
      console.log('==== details of====='+ id)
      resolve("hello "+ id);}
    , 100)
    })

}


const exe=async()=>{
//array1.forEach(async (element) => {
  for(var i=0;i<array1.length;i++){
  console.log('-------', array1[i])
  const details =  await fetchDetails(array1[i]);
  console.log('details is ------', details);
}
}

exe();
  
    // setTimeout(() => {
    //     console.log(i)
    //   }, 1000);
    // delay(i);

//details();

function delay(i) {
  setTimeout(() => {
    console.log(array[i])
  }, 1000);
}