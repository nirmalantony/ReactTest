// let i
// for(i=0;i<3;i++)
// {
//     setTimeout(() => {
//         console.log(i);
//     }, 1);
    
// };

