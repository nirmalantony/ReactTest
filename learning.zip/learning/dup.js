
const arry =['A', 'B', 'A', 'C', 'B'];

const s= arry.filter((a,b) => a!=b);
console.log(s)