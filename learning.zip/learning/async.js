const f1 = () =>
{
    console.log('1');
}

const f2 =   () =>
{ 
    return new Promise((resolve)=>{
    setTimeout(()=>{
      resolve(console.log("2"));}
    , 10)
    })
    
}

const f3 = (s)=>{

    console.log('3');
}

const f4 = async ()=>{
    f1();
   await f2();
    f3();
}

f4();