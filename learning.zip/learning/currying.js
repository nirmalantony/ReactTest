import curry from 'curry-function'; 
function sum(a, b) {
    return a + b;
  }
  
  let curriedSum = curry(sum); // using _.curry from lodash library
  
  console.log( curriedSum(1, 2) ); // 3, still callable normally
  console.log( curriedSum(1)(2) ); // 3, called partially