// let a = [6,-1 ,2]
// var b= [6,-1 ,2]

// console.log(b)
// console.log(a)

// var a;
// function a()
// {

// }
// console.log(a);

const b= [1,2,3,4]
let [,...d]=b;
console.log(d)