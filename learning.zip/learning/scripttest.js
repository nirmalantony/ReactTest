let numbers = [ 9,1,4,7, 3, 5, 6];
numbers.sort((a, b) => b - a);
console.log(numbers); // [ 1, 2, 3, 4, 5, 6, 7 ]

numbers.filter((ind, num)=>
{

});