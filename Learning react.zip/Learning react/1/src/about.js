import React from 'react'


 class about extends React.Component
{

    render()
    {
        return(
            <div>
                This is the about page
            </div>
        )
    }

}

export default about;