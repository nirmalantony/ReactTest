import React from 'react'
import Child from './child'

 class home extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            textval:""
        }
    }

    changetext=(event)=>
    {
        debugger;
        this.setState(
            {
                textval: event.target.value
            }
        );
    }

    clickme=()=>
    {
        alert(this.state.textval)
    }
    

    render()
    {
        return(
            <div>
                This is the home page
                <Child txtval={"hello"} txtonchange={this.changetext} buttonClick={this.clickme}/>
            </div>
        )
    }

}

export default home;