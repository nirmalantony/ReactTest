const Child=(props)=>
{
    return(
        <div>child component
            <input type={Text} onChange={props.txtonchange} ></input>
            <input type="button" value="Click me" onClick={props.buttonClick}></input>
        </div>
    )
}

export default Child;