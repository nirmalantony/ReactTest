import React from 'react';

const f1 = (props) =>{

    return(
        <div>
            <input type={Text} value={this.props.textval}></input>
        </div>
    )
}