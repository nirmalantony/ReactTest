import React, { Component } from 'react';
import logo from './logo.svg';
import { Counter } from './features/counter/Counter';
import './App.css';

import fun from './func.js'

export class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      val: "hi"
    };
  }
  render()
  {
  return (
    <div className="App">
      <header className="App-header">
       {/* <fun textval={this.state.val}/> */}
       
      </header>
    </div>
  );
}
}

export default App;
