import logo from './logo.svg';
import './App.css';

function App() {
  constructor(props)
  {
    this.state({
      course:
      {
        title:"title1"
      }
    })
  }
  return (
    <div className="App">
      <header className="App-header">
        <input type="text"></input>
      </header>
    </div>
  );
}

export default App;
