import React from 'react';
import { BrowserRouter,Route, Switch, Link } from 'react-router-dom';
import testpage from './test'

class App extends React.Component {
   render() {
      return (
        
         <div>     
           <BrowserRouter>
         <ul>
              <li>
                <Link to="/home">Home</Link>
              </li>
              <li>
                <Link to="/test1">Test 1</Link>
              </li>
              <li>
                <Link to="/test2">Test 2</Link>
              </li>
              <li>
                <Link to="/test3">Test 3</Link>
              </li>
            </ul>   
         <Switch>
         <Route path="/test1" component={testpage} />
        </Switch>
        </BrowserRouter>   
         </div>
      )
   }
}
export default App;