import React from 'react';
class test extends React.Component {
    render() {
       return (
          <div>
             <h1>helloo</h1>
          </div>
       )
    }
 }

 export default test;